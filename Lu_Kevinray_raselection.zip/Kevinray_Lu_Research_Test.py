import requests
import json
from sklearn.mixture import GaussianMixture

data = []
#prepare data
for i in range(30):
    #get data of draws and modify into integer lists
    flip = requests.get("https://24zl01u3ff.execute-api.us-west-1.amazonaws.com/beta")
    result = json.loads(flip.content)
    result = [int(i) for i in result['body'][1:-1].split(', ')]
    #reorder the list (see write-up)
    data.append(sorted(result))

#fit model
gm = GaussianMixture(n_components=2).fit(data)

#print out results
print("The estimates of thetas of the two coins are:", [sum(i)/len(i) for i in gm.means_][0], [sum(i)/len(i) for i in gm.means_][1])
print("The EM algorithm converges in", gm.n_iter_, "steps")
